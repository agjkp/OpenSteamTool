OpenSteamTool - portable install
================================

INSTALL
1. Close Steam completely (Steam menu > Exit).
2. Copy EVERYTHING in this folder into your Steam folder
   (usually C:\Program Files (x86)\Steam).
   If Windows asks, choose "Replace the files in the destination".
3. Start Steam.

LUA FILES
- Put your .lua files in:  Steam\config\lua
- NOT in config\stplug-in - this build only reads config\lua.
- You can add files while Steam is running; they show up in the library
  within a second or two, including many files at once.

WHAT'S INCLUDED
- OpenSteamTool.dll, xinput1_4.dll, dwmapi.dll   (no installs needed)
- opensteamtool\pattern, opensteamtool\ipc       (saved Steam patterns, so it
  works even if GitHub can't be reached; newer Steam versions are downloaded
  automatically on startup)

IF NOTHING SHOWS
- Make sure Steam was fully closed before copying, then restart Steam.
- Check that OpenSteamTool.dll and xinput1_4.dll are directly in the Steam
  folder (next to steam.exe), not in a subfolder.

UNINSTALL
Close Steam and delete OpenSteamTool.dll, xinput1_4.dll and dwmapi.dll from
the Steam folder.
